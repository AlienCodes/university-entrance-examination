import sys,json,re,threading,http.server,functools,os,tempfile,time
from pathlib import Path
root=Path('/workspace/ielts-repo'); base=Path('/workspace/ielts/batch/editor'); pid=sys.argv[1]; files=base/pid
sys.path.insert(0,str(root/'雅思/学术阅读/tools'));import lesson, pilot_video as pv
from playwright.sync_api import sync_playwright
m=pv.engine
m.zh_html=pv.ielts_zh_html
lesson.TEXT=files/'双语精读.tsv';lesson.LESSON=files;lesson.PID=pv.PID=pid
meta=json.loads((files/'篇目信息.json').read_text())
m.SPLIT.update(json.loads((files/'分屏.json').read_text()));m.NAMES+=meta['zh_names']
p=lesson.load()
p.update(year=2005+meta['book'])
probe='--full-header-probe' in sys.argv[2:]
if probe:
 meta['short_title_en'],meta['short_title_zh']=meta['title'],meta['title_zh']
expected=pv.expected_screens(p)
cet_slide=m.sentence_slide
def short_header_slide(p,*args,**kwargs):
 brief={**p,'passage':f"Passage {meta['passage']} · "+meta['short_title_en'],'title':meta['short_title_zh']}
 slide=cet_slide(brief,*args,**kwargs)
 return slide
m.sentence_slide=short_header_slide
if probe:
 original_screens=m.screens
 m.screens=lambda obj:original_screens(obj)[:2]
def handler(*a,**kw):
 return Quiet(*a,directory=str(root),**kw)
class Quiet(http.server.SimpleHTTPRequestHandler):
 def log_message(self,*a):pass
 def do_GET(self):
  if self.path.startswith('/local-stress-preview'):
   body=(base/(pid+'-'+str(os.getpid())+'-layout.html')).read_bytes()
   self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
  else:super().do_GET()
server=http.server.ThreadingHTTPServer(('127.0.0.1',0),handler);threading.Thread(target=server.serve_forever,daemon=True).start()
url=f'http://127.0.0.1:{server.server_port}'
class Local:
 def write_text(self,html,*args): (base/(pid+'-'+str(os.getpid())+'-layout.html')).write_text(html.replace(root.as_uri(),url))
 def as_uri(self):return url+'/local-stress-preview?cache='+str(time.time_ns())
m.check_names(p)
import hashlib
original_sha=hashlib.sha256(lesson.TEXT.read_bytes()).hexdigest()
problems=[];fonts={}
with sync_playwright() as pw:
 br=pw.chromium.launch(executable_path='/workspace/ielts/batch/chromium141/chrome-linux/chrome')
 pg=br.new_page(viewport=dict(width=m.W,height=m.H),device_scale_factor=1)
 for i,label,fit,sizes in m.layout(pg,p,Local()):
  errors=m.screen_checks(pg,label,fit,sizes)
  if fit:errors+=pv.reference_errors(pg,expected[i-1],label)
  if errors:problems.append([i,label,*errors]); print(i,label,sizes,errors,flush=True)
  if fit:fonts[label]=sizes
 br.close()
server.shutdown()
(base/(pid+('-probe.json' if probe else '-layout-results.json'))).write_text(json.dumps(dict(problems=problems,fonts=fonts),ensure_ascii=False,indent=1))
print('screens',1+len(fonts),'problems',len(problems),'English sizes',sorted({s[0] for s in fonts.values()}),'vocab sizes',sorted({s[1] for s in fonts.values()}))

if not probe and not problems and original_sha==hashlib.sha256(lesson.TEXT.read_bytes()).hexdigest():
 review=json.loads((base/(pid+'-preflight.json')).read_text());review['metadata_sha256']=hashlib.sha256((files/'篇目信息.json').read_bytes()).hexdigest();review['split_sha256']=hashlib.sha256((files/'分屏.json').read_bytes()).hexdigest();review['mobile_layout']={'total_screens':len(fonts)+1,'english_css_px':sorted({s[0] for s in fonts.values()}),'vocabulary_css_px':sorted({s[1] for s in fonts.values()}),'issues':0};(files/'content-review.json').write_text(json.dumps(review,ensure_ascii=False,indent=1)+'\n')
