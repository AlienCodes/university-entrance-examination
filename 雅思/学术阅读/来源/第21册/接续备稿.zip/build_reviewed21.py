import sys, re, json, hashlib, itertools
from pathlib import Path
base=Path('/workspace/ielts/batch/editor')
pid=sys.argv[1]
out=base/pid
out.mkdir(exist_ok=True)
src=json.loads((base.parent/'edition21'/'source'/f'{pid}.json').read_text())
raw=(base/(pid+'-draft.txt')).read_text()
lines=[l for l in raw.splitlines() if l.strip()]
metadata={}
groups=[]
for ln in lines:
 if ln.startswith('!'):
  k,v=ln[1:].split('|',1)
  metadata[k]=v
 else: groups.append(ln.split('||'))
orig=src['paragraphs']
count=sum(map(len,orig))
assert len(groups)==count,(len(groups),count)
n=0;entries=[];lemma={};rowlemma={};cuts={};paragraphs=[];allterms=[]
for para in orig:
 rows=[]
 for en in para:
  n+=1; line=groups[n-1]; assert int(line[0])==n,(n,line[0])
  _,zh,annotations,*anchors=line; chunks=zh.split('§');zh=''.join(chunks)
  assert len(chunks)==len(anchors)+1,(n,zh,anchors)
  for at in anchors: assert en.count(at)==1,(n,at)
  if anchors: cuts[str(n)]={'at':anchors,'zh':chunks}
  occ=set();terms=[]
  for slot,t in enumerate(annotations.split(';')):
   form,meaning=t.split('|')
   pair=form.split('>')
   term=pair[0]; head=pair[-1] if len(pair)>1 else term.lower()
   assert meaning.strip()==meaning and meaning
   spans=list(re.finditer(r'(?<!\w)'+re.escape(term)+r'(?!\w)',en,re.I));assert spans,(n,term,en)
   positions={i for s in spans for i in range(*s.span())}
   assert not occ.intersection(positions),(n,term,en)
   for a in anchors: assert all(not (s.start()<en.index(a)<s.end()) for s in spans),(n,term,a)
   occ.update(positions);terms.append(term+'|'+meaning);allterms.append(head)
   if term in lemma and lemma[term]!=head:rowlemma[f'{n}.{slot}']=head
   elif term.lower()!=head:lemma[term]=head
  row=[en,zh]+terms;rows.append('\t'.join(row));entries.append(row)
 paragraphs.append('\n'.join(rows))
tsv=out/'双语精读.tsv'
tsv.write_text('\n\n'.join(paragraphs)+'\n')
def save(f,data):(out/f).write_text(json.dumps(data,ensure_ascii=False,indent=1)+'\n')
if 'title_zh' in metadata:src['title_zh']=metadata['title_zh']
if 'printed_pages' in metadata:src['printed_pages']=[int(x) for x in metadata['printed_pages'].split(',')]
short=metadata.get('short',src['title']+'|'+src['title_zh']).split('|')
names=metadata.get('names','').split('|') if metadata.get('names') else []
args={k:src[k] for k in ['book','test','passage','title','title_zh','docx_paragraphs','source_sha256','passage_provenance']}
meta=dict(**args,short_title_en=short[0],short_title_zh=short[1],genre=metadata['genre'],zh_names=names,pronunciation={},lemmas=lemma)
if short!=[src['title'],src['title_zh']]:meta['header']={'english':short[0],'chinese':short[1]}
if rowlemma:meta['row_lemmas']=rowlemma
if src['footnotes']:
 meta['source_footnotes']=src['footnotes']
 if 'footnote_zh' in metadata:meta['source_footnotes_zh']=metadata['footnote_zh'].split('|')
if src['subtitle']:
 meta['subtitle']=src['subtitle']
 subtitle_words=''.join(src['subtitle'].split())
 assembled=''; zh_parts=[]
 for source_en,source_zh,*_ in entries:
  assembled+=''.join(source_en.split());zh_parts.append(source_zh)
  if assembled==subtitle_words:break
  assert subtitle_words.startswith(assembled),(pid,'subtitle mismatch',source_en)
 assert assembled==subtitle_words,(pid,'subtitle partial')
 meta['subtitle_zh']=''.join(zh_parts)
save('篇目信息.json',meta);save('分屏.json',{pid:cuts})
review=[{'check':x} for x in metadata['checks'].split('|')] if 'checks' in metadata else json.loads((base/'source20.json').read_text())['lessons'][pid]['language_review']
r=dict(source=f"剑桥雅思{src['book']} Academic，用户上传21.docx，Word正文第{src['docx_paragraphs'][0]}–{src['docx_paragraphs'][-1]}段，原件SHA-256 {src['source_sha256']}",title=src['title'],text_sha256=hashlib.sha256(tsv.read_bytes()).hexdigest(),paragraphs=len(paragraphs),sentences=n,vocabulary=len(allterms),distinct_headwords=len(set(h.casefold() for h in allterms)),split_sentences=len(cuts),checked=['全部英文逐句对照已核原书的录入稿，保持正文顺序与原文分段。','中译保持原句的语气、范围、条件和因果；词汇标记逐项对应原文词形及该句中的意思。']+[i['check'] for i in review])
(base/f'{pid}-preflight.json').write_text(json.dumps(r,ensure_ascii=False,indent=1)+'\n')
print(pid,n,len(allterms),len(cuts),r['text_sha256'],flush=True)
